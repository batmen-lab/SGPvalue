blastp_url=$1
db_dir=$2
query_url=$3
output_url=$4

python ../blastp_wrapper.py \
  --num_shuffle 50 \
  --lookup_url ./pvs_f0_t34_b0.001_N1e10_m50_ls33_ss15_l0_s3.txt \
  --blastp_url $blastp_url \
  blastp \
  -gapopen 9 \
  -gapextend 2 \
  -num_alignments 0 \
  -num_descriptions 100 \
  -evalue 1000 \
  -matrix BLOSUM62 \
  -db $db_dir \
  -query $query_url \
  -out $output_url


### Command: 
# bash run_blastp.sh /mnt/d/proj/ncbi-blast-2.14.0+-src/c++/ReleaseMT/bin/./blastp ./db_astral/astral_db ./astral-scopedom-seqres-gd-sel-gs-bib-40-2.08.fa ./astral.BL62.blastp
# bash run_blastp.sh /mnt/d/proj/ncbi-blast-2.14.0+-src/c++/ReleaseMT/bin/./blastp ./db_astral/astral_db ./astral-subset.fa ./astral-subset.BL62.blastp



