makeblastdb=$1
db_url=$2
db_dir=$3


${makeblastdb} -in ${db_url} -parse_seqids -dbtype prot -out ${db_dir}
if [ $? -eq 0 ];
then
    echo "$0: db created successfully"
else 
    echo "$0: db creation failed"
    exit 1
fi

### Command: 
# bash run_makeblastdb.sh /mnt/d/proj/ncbi-blast-2.14.0+-src/c++/ReleaseMT/bin/./makeblastdb ./astral-scopedom-seqres-gd-sel-gs-bib-40-2.08.fa ./db_astral/astral_db
